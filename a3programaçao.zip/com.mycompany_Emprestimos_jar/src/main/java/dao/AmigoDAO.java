
package DAO;
import Model.Amigo;
   import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class AmigoDAO {

    private Connection connection;

    public AmigoDAO(Connection connection) {
        this.connection = connection;
    }

    public void inserirAmigo(Amigo amigo) throws SQLException {
        String sql = "INSERT INTO Amigo (nome, telefone) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, amigo.getNome());
            stmt.setString(2, amigo.getTelefone());
            stmt.executeUpdate();
        }
    }

    public List<Amigo> listarAmigos() throws SQLException {
        List<Amigo> amigos = new ArrayList<>();
        String sql = "SELECT * FROM Amigo";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Amigo amigo = new Amigo();
                amigo.setId(rs.getInt("id"));
                amigo.setNome(rs.getString("nome"));
                amigo.setTelefone(rs.getString("telefone"));
                amigos.add(amigo);
            }
        }
        return amigos;
    }

    public Amigo buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM Amigo WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Amigo amigo = new Amigo();
                    amigo.setId(rs.getInt("id"));
                    amigo.setNome(rs.getString("nome"));
                    amigo.setTelefone(rs.getString("telefone"));
                    return amigo;
                }
            }
        }
        return null;
    }

    public void atualizarAmigo(Amigo amigo) throws SQLException {
        String sql = "UPDATE Amigo SET nome = ?, telefone = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, amigo.getNome());
            stmt.setString(2, amigo.getTelefone());
            stmt.setInt(3, amigo.getId());
            stmt.executeUpdate();
        }
    }

    public void deletarAmigo(int id) throws SQLException {
        String sql = "DELETE FROM Amigo WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
} 

