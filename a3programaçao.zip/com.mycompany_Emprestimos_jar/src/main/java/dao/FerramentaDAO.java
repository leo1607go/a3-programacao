
package DAO;
import Model.Ferramenta;
    import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FerramentaDAO {

    private Connection connection;

    public FerramentaDAO(Connection connection) {
        this.connection = connection;
    }

    public void inserirFerramenta(Ferramenta ferramenta) throws SQLException {
        String sql = "INSERT INTO Ferramenta (nome, marca, custo_aquisicao) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, ferramenta.getNome());
            stmt.setString(2, ferramenta.getMarca());
            stmt.setDouble(3, ferramenta.getCustoAquisicao());
            stmt.executeUpdate();
        }
    }

    public List<Ferramenta> listarFerramentas() throws SQLException {
        List<Ferramenta> ferramentas = new ArrayList<>();
        String sql = "SELECT * FROM Ferramenta";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Ferramenta ferramenta = new Ferramenta();
                ferramenta.setId(rs.getInt("id"));
                ferramenta.setNome(rs.getString("nome"));
                ferramenta.setMarca(rs.getString("marca"));
                ferramenta.setCustoAquisicao(rs.getDouble("custo_aquisicao"));
                ferramentas.add(ferramenta);
            }
        }
        return ferramentas;
    }

    public Ferramenta buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM Ferramenta WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Ferramenta ferramenta = new Ferramenta();
                    ferramenta.setId(rs.getInt("id"));
                    ferramenta.setNome(rs.getString("nome"));
                    ferramenta.setMarca(rs.getString("marca"));
                    ferramenta.setCustoAquisicao(rs.getDouble("custo_aquisicao"));
                    return ferramenta;
                }
            }
        }
        return null;
    }

    public void atualizarFerramenta(Ferramenta ferramenta) throws SQLException {
        String sql = "UPDATE Ferramenta SET nome = ?, marca = ?, custo_aquisicao = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, ferramenta.getNome());
            stmt.setString(2, ferramenta.getMarca());
            stmt.setDouble(3, ferramenta.getCustoAquisicao());
            stmt.setInt(4, ferramenta.getId());
            stmt.executeUpdate();
        }
    }

    public void deletarFerramenta(int id) throws SQLException {
        String sql = "DELETE FROM Ferramenta WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public double calcularCustoTotalFerramentas() throws SQLException {
        String sql = "SELECT SUM(custo_aquisicao) AS custo_total FROM Ferramenta";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getDouble("custo_total");
            }
        }
        return 0.0;
    }
}

