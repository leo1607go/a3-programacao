
package Model;

import java.util.List;
import java.util.ArrayList;


public class Amigo {
   
    private String nome;
    private String telefone;
    private final    List<Ferramenta> ferramentasEmprestadas;

    public Amigo(String nome, String telefone) {
        this.nome = nome;
        this.telefone = telefone;
        this.ferramentasEmprestadas = new ArrayList<>();
    }

    public Amigo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters e Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

   
    public List<Ferramenta> getFerramentasEmprestadas() {
        return ferramentasEmprestadas;
    }

    // Método para emprestar uma ferramenta ao amigo
    public void emprestarFerramentas(Ferramenta ferramenta) {
        ferramentasEmprestadas.add(ferramenta);
    }

    // Método para devolver uma ferramenta ao amigo
    public void devolverFerramentas(Ferramenta ferramenta) {
        ferramentasEmprestadas.remove(ferramenta);
    }

    // Método para verificar se o amigo tem ferramentas não devolvidas
    public boolean temFerramentasNaoDevolvidas() {
        return !ferramentasEmprestadas.isEmpty();
    }

    public void emprestarFerramenta(Ferramenta ferramenta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void devolverFerramenta(Ferramenta ferramenta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setId(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

