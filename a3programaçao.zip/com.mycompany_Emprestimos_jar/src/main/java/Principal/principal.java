/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

    package principal;
    import visao.frmMenuPrincipal;
    
    public class principal {
        public static void main(String[] args) {
    // Instancia a interface gráfica
         frmMenuPrincipal objetotela = new frmMenuPrincipal();
    // Torna a janela visível
          objetotela.setVisible(true);
        }
    }
//principal
    

